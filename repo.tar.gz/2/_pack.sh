#!/bin/sh
cd ..
./pack.sh